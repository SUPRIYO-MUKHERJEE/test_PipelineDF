docker login --name 3107e6123ca042ca8691f618af7d5dd2.azurecr.io --username 3107e6123ca042ca8691f618af7d5dd2 --password OdQSnN/jMD9PLs17fawa/UUjeakNpXvD
sudo docker pull 3107e6123ca042ca8691f618af7d5dd2.azurecr.io/diabetes-model-score:11
sudo docker login 20.51.225.57:1200 -u admin -p master123
